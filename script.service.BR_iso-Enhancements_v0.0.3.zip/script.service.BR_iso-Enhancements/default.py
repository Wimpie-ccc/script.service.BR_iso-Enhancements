import os, sys, re, urllib
import xbmc, xbmcaddon

__addon__ = xbmcaddon.Addon()
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonname__ = __addon__.getAddonInfo('name')
__addonPath__ = __addon__.getAddonInfo('path')
__addonResourcePath__ = xbmc.translatePath(os.path.join(__addonPath__, 'resources'))
__addonIconFile__ = xbmc.translatePath(os.path.join(__addonPath__, 'icon.png'))
sys.path.append(__addonResourcePath__)

# Compiling reg-ex at the start of a program makes it faster while using them in the program
# reg-ex for 1 iso with 1 or more movies on it, play 1 movie (.PlayList[12345].)		  
BR_1_iso = re.compile('[.]PlayList[[]\d\d\d\d\d[]][.]', re.IGNORECASE)
# reg-ex for 1 iso with 1 or more movies on it, play 1 movie with time offset <> 0, tv shows in 1 long video(.PlayList[12345-uu_mm_ss].)
BR_1_iso_offset = re.compile('[.]PlayList[[]\d\d\d\d\d[-]\d\d[_]\d\d[_]\d\d[]][.]', re.IGNORECASE)
# reg-ex for multi-iso movie (.PlayList[1.12345].  .PlayList[2.78915].  .PlayList[3.71965].)
BR_multi_iso = re.compile('[.]PlayList[[]\d[.]\d\d\d\d\d[]][.]', re.IGNORECASE)
# reg-ex for tv episodes on a br iso (.SxxEyy[02515]. of .SxxEyy[02512-uu_mm_ss].)
BR_tv_iso = re.compile('[.]S\d\dE\d\d[[]\d\d\d\d\d[]][.]|[.]S\d\dE\d\d[[]\d\d\d\d\d-\d\d_\d\d_\d\d[]][.]', re.IGNORECASE)
# reg-ex to get the playlist number 12345 form eg .PlayList[12345].
BR_playliststr = re.compile('\d\d\d\d\d')
# reg-ex to get the time string (uu_mm_ss)
BR_timestr = re.compile('\d\d[_]\d\d[_]\d\d')

LOG_NONE = 0
LOG_ERROR = 1
LOG_INFO = 2
LOG_DEBUG = 3

# This class will log messages in Kodi.log
# Some things will be logged others not, depending on loglevel.
def log(level, msg):
    if level <= settings.logLevel:
        if level == LOG_ERROR:
            log_level = xbmc.LOGERROR
        elif level == LOG_INFO:
            log_level = xbmc.LOGINFO
        elif level == LOG_DEBUG:
            log_level = xbmc.LOGDEBUG
        xbmc.log("[Blu-Ray iso Enhancements]: " + str(msg), log_level)


# This class is the interface between the internal default settings and the user.
# The user adjust the settings to his/her likings in Kodi. This class will make
# sure that the addon knows that the user changed a setting.
class settings():
    # Init with some default values for the addon
    def init(self):
        addon = xbmcaddon.Addon()
        self.logLevel = addon.getSetting('log_level')
        if self.logLevel and len(self.logLevel) > 0:
            self.logLevel = int(self.logLevel)
        else:
            self.logLevel = LOG_INFO
        self.service_enabled = addon.getSetting('enabled') == 'true'
    
    def __init__(self):
        self.init()

    # Read setting that user can change from within Kodi    
    def readSettings(self):
        addon = xbmcaddon.Addon()    

        self.service_enabled = addon.getSetting('enabled') == 'true'
        self.logLevel = int(addon.getSetting('log_level'))

        log(LOG_DEBUG,
                 '\n##### BR iso Enhancements Settings #####\n' \
                 'enabled: {0}\n' \
                 'Log Level: {1}\n' \
                 '##### BR iso Enhancements Settings #####\n'
                 .format(self.service_enabled, self.logLevel)
                 )

# Needed so we can use it in the next class.
settings = settings()				 
		  
# This class is called when the user changes some settings.
class BR_iso_Enhancements_Monitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)

    # This is the function that signals that the user just changed a setting.
    # First default settings will be loaded, then we read the user-defined settings and
    # overwrite these default settings if needed.   
    def onSettingsChanged(self):
        settings.init()
        settings.readSettings()

# Main funtion of the addon 		
class Main:
    # This function get automatically called when an object of this class gets created.
    def __init__(self):
        self._init_vars()
        if (not settings.service_enabled):
            log(LOG_INFO, "Service not enabled")
        settings.readSettings()
        self._daemon()

    # Defining our xbmc.monitor and xbmc.player
    def _init_vars(self):
        self.Monitor = BR_iso_Enhancements_Monitor()
        self.Player = BR_iso_Enhancements_Player()

    # Endless loop where the addon keeps waiting for events:
    # - onPlayBackStarted : user pressed 'play' for a video
    # - onSettingsChanged : user changed a setting for this addon
    def _daemon(self):
        while (not xbmc.abortRequested):
            xbmc.sleep(500)

# Ours new player class, here we change the behavior of the default xbmc.player			
class BR_iso_Enhancements_Player(xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)

    # URL escape the filename so that it works with xbmc.player.play
    # Needs following format: bluray://[udf://[path to iso]/]/BDMV/PLAYLIST/12345.mpls
    # with [path to iso] eg: 'M:/testdir/test_movie.bluray.iso'
    # and 12345 the playlist number to play. Playlist number needs to be 5 digits.
    def URL_Escape_Playlist(self, iso_filename, playlist):
        result_str = urllib.quote(iso_filename, safe='()')
        result_str = 'udf://' + result_str + '/'
        result_str = urllib.quote(result_str, safe='()')
        result_str = 'bluray://' + result_str + '/BDMV/PLAYLIST/' + playlist + '.mpls'
        return result_str

    # Convert the seektime in the filename (format: uu_mm_ss) to seconds.
    # result = (3600 * uu) + (60 * mm) + ss
    def ConvertTimeToSecs(self, file_time):
        hours = int(file_time[0:2])
        mins = int(file_time[3:5])
        secs = int(file_time[6:])
        result_int = (3600 * hours) + (60 * mins) + secs
        return result_int                  

    # Ah. Something has started playing. Lets see if it is a blu-ray, and
    # if we have to play a specific playlist
    def onPlayBackStarted(self):
        # We only need to do someting if it is a video file. No need to look at audio-files...
        if settings.service_enabled and self.isPlayingVideo():
            log(LOG_DEBUG, 'We play a videofile while the addon is enabled')
            BR_filename = self.getPlayingFile()
            log(LOG_DEBUG, "Filename = " + BR_filename)

            # When we start playing a new blu-ray, self.getPlayingFile() will return a filename
            # in a 'normal' format, eg: "M:\Test_dir\testmovie1.PlayList[00003].BluRay.iso"
            # When this addon changes the playlist, or the starttime, then self.getPlayingFile()
            # will return a filename in an URL escaped format, eg:
            # "bluray://udf%3A%2F%2FM%253A%255CTest_dir%255Ctestmovie1.PlayStream%255B00003%255D.BluRay.iso%2F/BDMV/PLAYLIST/00003.mpls"
            # This prevents an endless loop.

            # 1 movie iso
            BR_re_result = BR_1_iso.search(BR_filename)
            if BR_re_result:                    
                self.stop()

                # Get : ".PlayList[12345]."
                BR_string1 = BR_re_result.group()
                log(LOG_DEBUG, 'Type of iso is 1 iso playlist: ' + BR_string1)

                # get playlist number : "12345"
                BR_re_result2 = BR_playliststr.search(BR_string1)
                BR_string2 = BR_re_result2.group()
                log(LOG_DEBUG, "1 iso playlist = " + BR_string2)

                # Transform filename and playlist number so that the player will play this.
                # We need to URL escape those things.
                videofile = self.URL_Escape_Playlist(BR_filename, BR_string2)

                # Restart playing the video from the blu-ray with the correct playlist.
                log(LOG_DEBUG, "Replaying file : " + videofile)
                self.play(videofile)

            # 1 movie with offset start iso
            BR_re_result = BR_1_iso_offset.search(BR_filename)
            if BR_re_result:                    
                self.stop()

                # Get : ".PlayList[12345-uu_mm_ss]."
                BR_string1 = BR_re_result.group()
                log(LOG_DEBUG, 'Type of iso is 1 iso playlist + offset: ' + BR_string1)

                # get playlist number : "12345"
                BR_re_result2 = BR_playliststr.search(BR_string1)
                BR_string2 = BR_re_result2.group()
                log(LOG_DEBUG, "Playlist = " + BR_string2)
                log(LOG_DEBUG, "Filename = " + BR_filename)

                # Transform filename and playlist number so that the player will play this.
                # We need to URL escape those things.
                videofile = self.URL_Escape_Playlist(BR_filename, BR_string2)

                # Get the seektime : "uu_mm_ss"
                BR_time_str = BR_timestr.search(BR_string1).group()
                BR_time_int = self.ConvertTimeToSecs(BR_time_str)                    

                # Restart playing the video from the blu-ray with the correct playlist and seektime.
                log(LOG_DEBUG, "Replaying file : " + videofile)
                log(LOG_DEBUG, "Seektime = " + str(BR_time_int))
                # Does not work yet...
                # video_seek = int('5')
                # self.play(item=videofile, startpos=video_seek)
                # Do this instead, but I don't like it. Better to start video on correct time,
                # instead of start video and then seek to correct time
                self.play(videofile)
                self.seekTime(BR_time_int)

                    
        else:
            log(LOG_DEBUG, 'File played is no video file or the addon is not enabled')

			
# Real start of the addon
# Print to Kodi.log that the addon has started
# The addon works
# Print to Kodi.log that the addon has been stopped
if ( __name__ == "__main__" ):
    log(LOG_INFO, 'service {0} version {1} started'.format(__addonname__, __addonversion__))
    main = Main()
    log(LOG_INFO, 'service {0} version {1} stopped'.format(__addonname__, __addonversion__))
