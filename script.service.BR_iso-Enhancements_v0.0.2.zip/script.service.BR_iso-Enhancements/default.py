

import os, sys, re, urllib2, urllib
import xbmc, xbmcaddon

if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson

__addon__ = xbmcaddon.Addon()
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonname__ = __addon__.getAddonInfo('name')
__addonPath__ = __addon__.getAddonInfo('path')
__addonResourcePath__ = xbmc.translatePath(os.path.join(__addonPath__, 'resources'))
__addonIconFile__ = xbmc.translatePath(os.path.join(__addonPath__, 'icon.png'))
sys.path.append(__addonResourcePath__)

# M:\Over_te_copieren\TATI BD 4.PlayStream[01984].iso
# Compiling reg-ex at the start of a program makes it faster while using them in the program
# reg-ex for 1 iso with 1 or more movies on it, play 1 movie (.PlayStream[12345].)		  
BR_1_iso = re.compile('[.]PlayStream[[]\d\d\d\d\d[]][.]', re.IGNORECASE)
# reg-ex for 1 iso with 1 or more movies on it, play 1 movie with time offset <> 0 (some copyprotections)(.PlayStream[12345-uu_mm_ss].)
BR_1_iso_offset = re.compile('[.]PlayStream[[]\d\d\d\d\d[-]\d\d[_]\d\d[_]\d\d[]][.]', re.IGNORECASE)
# reg-ex for multi-iso movie (.PlayStream[1.12345].  .PlayStream[2.78915].  .PlayStream[3.71965].)
BR_multi_iso = re.compile('[.]PlayStream[[]\d[.]\d\d\d\d\d[]][.]', re.IGNORECASE)
# reg-ex for tv episodes on a br iso (.SxxEyy[02515]. of .SxxEyy[02512-uu_mm_ss].)
BR_tv_iso = re.compile('[.]S\d\dE\d\d[[]\d\d\d\d\d[]][.]|[.]S\d\dE\d\d[[]\d\d\d\d\d-\d\d_\d\d_\d\d[]][.]', re.IGNORECASE)
# reg-ex to get the streamnumber 12345 form eg .PlayStream[12345].
BR_stream = re.compile('\d\d\d\d\d')
# reg-ex to get the time string (uu_mm_ss)
BR_timestr = re.compile('\d\d[_]\d\d[_]\d\d')

LOG_NONE = 0
LOG_ERROR = 1
LOG_INFO = 2
LOG_DEBUG = 3

# Global str, prevents infinite loop in onPlayBackStarted
BR_PlayingFile = ""

# This class will log messages in Kodi.log
# Some things will be logged others not, depending on loglevel.
def log(level, msg):
    if level <= settings.logLevel:
        if level == LOG_ERROR:
            log_level = xbmc.LOGERROR
        elif level == LOG_INFO:
            log_level = xbmc.LOGINFO
        elif level == LOG_DEBUG:
            log_level = xbmc.LOGDEBUG
        xbmc.log("[Blu-Ray iso Enhancements]: " + str(msg), log_level)


# This class is the interface between the internal default settings and the user.
# The user adjust the settings to his/her likings in Kodi. This class will make
# sure that the addon knows that the user changed a setting.
class settings():
    # Init with some default values for the addon
    def init(self):
        addon = xbmcaddon.Addon()
        self.logLevel = addon.getSetting('log_level')
        if self.logLevel and len(self.logLevel) > 0:
            self.logLevel = int(self.logLevel)
        else:
            self.logLevel = LOG_INFO
        self.service_enabled = addon.getSetting('enabled') == 'true'
    
    def __init__(self):
        self.init()
        
    def readSettings(self):
        addon = xbmcaddon.Addon()    

        self.service_enabled = addon.getSetting('enabled') == 'true'
        self.logLevel = int(addon.getSetting('log_level'))

        log(LOG_DEBUG,
                 '\n##### BR iso Enhancements Settings #####\n' \
                 'enabled: {0}\n' \
                 'Log Level: {1}\n' \
                 '##### BR iso Enhancements Settings #####\n'
                 .format(self.service_enabled, self.logLevel)
                 )

# Needed so we can use it in the next class
settings = settings()				 
		  
# This class is called when the user changes some settings.
class BR_iso_Enhancements_Monitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)

    # This is the function that signals that the user just changed a setting
    # First default settings will be loaded, then we read the userdefined settings and
    # overwrite these default settings if needed    
    def onSettingsChanged(self):
        settings.init()
        settings.readSettings()

# Main funtion of the addon 		
class Main:
    # This function get automatically called when an object of this class gets created
    def __init__(self):
        self._init_vars()
        if (not settings.service_enabled):
            log(LOG_INFO, "Service not enabled")
        settings.readSettings()
        self._daemon()

    # Defining our xbmc.monitor and xbmc.player
    def _init_vars(self):
        self.Monitor = BR_iso_Enhancements_Monitor()
        self.Player = BR_iso_Enhancements_Player()

    # Endless loop where the addon keeps waiting for events:
    # - onPlayBackStarted : user pressed 'play' for a video
    # - onSettingsChanged : user changed a setting for this addon
    def _daemon(self):
        while (not xbmc.abortRequested):
            xbmc.sleep(500)

			
class BR_iso_Enhancements_Player(xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)

    # URL escape the filename so that it works with xbmc.player.play
    # Needs following format: bluray://[udf://[path to iso]/]/BDMV/PLAYLIST/12345.mpls
    # with [path to iso] eg: 'M:/testdir/test_movie.bluray.iso'
    # and 12345 the playlist number to play. Playlist number needs to be 5 digits.
    def URL_Escape_Playlist(self, iso_filename, play_stream):
        result_str = urllib.quote(iso_filename, safe='()')
        result_str = 'udf://' + result_str + '/'
        result_str = urllib.quote(result_str, safe='()')
        result_str = 'bluray://' + result_str + '/BDMV/PLAYLIST/' + play_stream + '.mpls'
        return result_str;

    # Convert the seektime in the filename (format: uu_mm_ss) to seconds.
    # result = (3600 * uu) + (60 * mm) + ss
    def ConvertTimeToSecs(self, file_time):
        hours = int(file_time[0:2])
        mins = int(file_time[3:5])
        secs = int(file_time[6:-1])
        result_int = (3600 * hours) + (60 * mins) + secs
        return result_int                  
        
    def onPlayBackStarted(self):
        global BR_PlayingFile
        if settings.service_enabled and self.isPlayingVideo():
            log(LOG_DEBUG, 'We play a videofile while the addon is enabled')
            BR_filename = self.getPlayingFile()
            log(LOG_DEBUG, "Filename = " + BR_filename)

            if BR_PlayingFile != BR_filename: # this is a new movie playing, not a movie we just changed streams off
                log(LOG_DEBUG, "We haven't played this file yet")
                log(LOG_DEBUG, "BR_PlayingFile: " + BR_PlayingFile)
                log(LOG_DEBUG, "BR_filename :" + BR_filename)                
                BR_PlayingFile = BR_filename

                # 1 movie iso
                BR_MO = BR_1_iso.search(BR_filename)
                if BR_MO:                    
                    self.stop()
                    BR_STR = BR_MO.group()
                    log(LOG_DEBUG, 'Type of iso is 1 iso playstream: ' + BR_STR)
                    BR_MO2 = BR_stream.search(BR_STR)
                    BR_STR2 = BR_MO2.group()
                    log(LOG_DEBUG, "1 iso playstream = " + BR_STR2)
            	    # filename bluray://[udf://[path to iso]/]/BDMV/PLAYLIST/000000.mpls
            	    videofile = self.URL_Escape_Playlist(BR_filename, BR_STR2)
                    log(LOG_DEBUG, "Replaying file : " + videofile)
                    self.play(videofile)
                    log(LOG_DEBUG, "Done playing 1 iso BR")

                # 1 movie with offset start iso
                BR_MO = BR_1_iso_offset.search(BR_filename)
                if BR_MO:                    
                    self.stop()
                    BR_STR = BR_MO.group()
                    log(LOG_DEBUG, 'Type of iso is 1 iso playstream + offset: ' + BR_STR)
                    BR_MO2 = BR_stream.search(BR_STR)
                    BR_STR2 = BR_MO2.group()
                    log(LOG_DEBUG, "playstream = " + BR_STR2)
                    log(LOG_DEBUG, "filename = " + BR_filename)
            	    # filename bluray://[udf://[path to iso]/]/BDMV/PLAYLIST/000000.mpls
                    videofile = self.URL_Escape_Playlist(BR_filename, BR_STR2)

                    test = BR_timestr.search(BR_STR).group()
                    BR_Time_STR2 = self.ConvertTimeToSecs(test)                    
                    log(LOG_DEBUG, "Time = " + str(BR_Time_STR2))

                    
                    log(LOG_DEBUG, "Replaying file : " + videofile)
                    self.play(videofile)
                    self.seekTime(BR_Time_STR2)
                    #video_seek = int('5')
                    #self.play(item=videofile, startpos=int('5000'))
                    log(LOG_DEBUG, "Done playing 1 iso + offset BR")





                    
            else:
                log(LOG_DEBUG, "We just changed the stream number, no need to change it again. (infinite loop prevented)")                
        else:
            log(LOG_DEBUG, 'File played is no video file or the addon is not enabled')

			
# Real start of the addon
# Print to Kodi.log that the addon has started
# The addon works
# Print to Kodi.log that the addon has been stopped
if ( __name__ == "__main__" ):
    log(LOG_INFO, 'service {0} version {1} started'.format(__addonname__, __addonversion__))
    main = Main()
    log(LOG_INFO, 'service {0} version {1} stopped'.format(__addonname__, __addonversion__))
